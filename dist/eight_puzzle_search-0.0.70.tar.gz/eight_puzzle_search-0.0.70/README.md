# 八数码问题练习包

Language: [English](https://github.com/VincentSHI1230/eight-puzzle-search/blob/main/README_en.md) | 简体中文 (Simplified Chinese)

---

一款用于辅助学习八数码问题搜索求解的 Python 包

## 安装

```bash
pip install --upgrade eight-puzzle-search
```

## 引入

```python
import eight_puzzle_search as eps
```

# 八数码问题练习包

Language: [English](README_en.md) | 简体中文(Simplified Chinese)

---

一款用于辅助学习八数码问题搜索求解的 Python 包
